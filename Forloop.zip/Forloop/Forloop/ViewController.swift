//
//  ViewController.swift
//  Forloop
//
//  Created by Rp on 25/10/18.
//  Copyright © 2018 Rp. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        var i = 1
        
        for var index in 0..<10
        {
            print(index)
            
        //    if index%2==0{
        //        print("even")
         //   }
         //   else{
         //       print("odd")
         //   }
            
            i = i + 500
            print(i)
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

